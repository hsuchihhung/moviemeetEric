module.exports = {
    testEnvironment: "jsdom",
    setupFilesAfterEnv: ["./src/test/setup.js"],
};
