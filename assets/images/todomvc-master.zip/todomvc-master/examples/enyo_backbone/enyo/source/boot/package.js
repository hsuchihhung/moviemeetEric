/* global enyo: false */
enyo.depends(
	"enyo.js",
	"ready.js",
	"../../loader.js",
	"boot.js"
);
