/*global enyo:false */
enyo.depends(
	'TaskModel.js'
);
